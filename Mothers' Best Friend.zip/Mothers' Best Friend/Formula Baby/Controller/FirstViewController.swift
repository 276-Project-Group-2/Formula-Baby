//
//  FirstViewController.swift
//  Formula Baby
//
//  Created by Alec Grover on 2018-07-03.
//  Copyright © 2018 Team NASK. All rights reserved.
//

import UIKit
import UserNotifications



class FirstViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet var babyName: UILabel!
    @IBOutlet var babyAge: UILabel!
    @IBOutlet var profilePicture: UIImageView!
    
    let imagePicker = UIImagePickerController()
    let defaults = UserDefaults.standard
    let date = Date()
    let calendar = Calendar.current
    
    
    @IBAction func newPictureButtonPressed(_ sender: Any) {
        
        imagePicker.allowsEditing = false
        imagePicker.sourceType = .photoLibrary
        
        present(imagePicker, animated: true, completion: nil)
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [String : Any])
    {
        
        picker.dismiss(animated: true, completion: nil)
        profilePicture.image = info[UIImagePickerControllerOriginalImage] as? UIImage
        let dataImage = UIImageJPEGRepresentation((info[UIImagePickerControllerOriginalImage] as? UIImage)!, 1.0)
        //let dataImage = newImage.jpgData()
        defaults.set(dataImage, forKey: "profilePicture")
    
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
    
    
    
    
    
    
    

    @IBAction func licenseAlert(_ sender: Any) {
        let alertController = UIAlertController(title: "License", message: "Copyright (c) 2018 Team NASK\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the \"Software\"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:\n\nThe above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.\n\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.", preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "Accept", style: UIAlertActionStyle.default, handler: nil))
        
        self.present(alertController, animated: true, completion: nil)
        
    }
    
    @IBAction func ActivateMorningBriefing(_ sender: Any) {
        let content = UNMutableNotificationContent()
        content.title = " Welcome to Morning breifing"
        content.subtitle = "Breifing on the amount of portion size recommended"
        content.body = "  it is recommended to offer a variety of solid foods at two to three feedings per day, as well as two snacks per day.From the age of 9 months to 12 months, it is recommended to offer a variety of solid foods at three feedings per day, as well as one to two snacks per day.From the age of 12 months to 24 months, it is recommended to offer a variety of solid foods from each of the food groups three to four time per day, as well as one to two snacks per day."
        content.badge = 1
        //let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        //let trigger = UNCalendarNotificationTrigger
        var date = DateComponents()
        date.hour = 14
        date.minute = 31
        let trigger = UNCalendarNotificationTrigger(dateMatching: date, repeats: true)
        let request = UNNotificationRequest(identifier: "timer done", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
        
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UNUserNotificationCenter.current().requestAuthorization(options:[.alert, .sound, .badge] , completionHandler: {didAllow, error in})
        
        
        profilePicture.layer.cornerRadius = profilePicture.frame.size.width / 2;
        profilePicture.clipsToBounds = true;
        
        
        imagePicker.delegate = self
        if (UserDefaults.standard.object(forKey: "profilePicture") != nil) {
            let temp = UserDefaults.standard.object(forKey: "profilePicture") as! Data
            profilePicture.image = UIImage(data: temp)
            
            
            let content = UNMutableNotificationContent()
            content.title = " Welcome to Morning breifing"
            content.subtitle = "Breifing on the amount of portion size recommended"
            content.body = "  it is recommended to offer a variety of solid foods at two to three feedings per day, as well as two snacks per day.From the age of 9 months to 12 months, it is recommended to offer a variety of solid foods at three feedings per day, as well as one to two snacks per day.From the age of 12 months to 24 months, it is recommended to offer a variety of solid foods from each of the food groups three to four time per day, as well as one to two snacks per day."
            content.badge = 1
            //let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
            //let trigger = UNCalendarNotificationTrigger
            var date = DateComponents()
            date.hour = 15
            date.minute = 20
            let trigger = UNCalendarNotificationTrigger(dateMatching: date, repeats: true)
            let request = UNNotificationRequest(identifier: "timer done", content: content, trigger: trigger)
            
            UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
        }
        
        
        
    }
        // Do any additional setup after loading the view, typically from a nib.
     

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    func monthCount() {
        let year = self.calendar.component(.year, from: self.date)
        let month = self.calendar.component(.month, from: self.date)
        let birthYear = Int(UserDefaults.standard.object(forKey: "birthYear") as! Int)
        let birthMonth = Int(UserDefaults.standard.object(forKey: "birthMonth") as! Int)
        let ageInMonths = ((month - birthMonth) + (12 * (year - birthYear)))
        self.babyAge.text = "\(ageInMonths) months"
        //return ageInMonths
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if (UserDefaults.standard.object(forKey: "Name") != nil) {
            babyName.text = UserDefaults.standard.object(forKey: "Name") as? String
            monthCount()
        }
        else {
            
            let MainDate = calendar.component(.day, from: date)
            defaults.set(MainDate,forKey: "MainDate")
            defaults.set(MainDate,forKey: "NapDate")

            
            
            
            
            //            let alert = UIAlertController(title: "Welcome", message: "Enter baby name", preferredStyle: .alert)
            //            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            //            present(alert, animated: true, completion: nil)
            
            let alert3 = UIAlertController(title: "And in what year?", message: "", preferredStyle: .alert)
            alert3.addAction(UIAlertAction(title: "\(self.calendar.component(.year, from: date))", style: .default, handler: {action in
                self.defaults.set(self.calendar.component(.year, from: self.date), forKey: "birthYear")
                self.monthCount()
            }))
            alert3.addAction(UIAlertAction(title: "\(self.calendar.component(.year, from: date) - 1)", style: .default, handler: {action in
                self.defaults.set(self.calendar.component(.year, from: self.date) - 1, forKey: "birthYear")
                self.monthCount()
            }))
            alert3.addAction(UIAlertAction(title: "\(self.calendar.component(.year, from: self.date) - 2)", style: .default, handler: {action in
                self.defaults.set(self.calendar.component(.year, from: self.date) - 2, forKey: "birthYear")
                self.monthCount()
            }))
            
            
            let alert2 = UIAlertController(title: "What month were they born in?", message: "", preferredStyle: .actionSheet)
            alert2.addAction(UIAlertAction(title: "January", style: .default, handler: { action in
                self.defaults.set(1, forKey: "birthMonth")
                self.present(alert3, animated: true, completion: nil)
            }))
            alert2.addAction(UIAlertAction(title: "February", style: .default, handler: { action in
                self.defaults.set(2, forKey: "birthMonth")
                self.present(alert3, animated: true, completion: nil)
            }))
            alert2.addAction(UIAlertAction(title: "March", style: .default, handler: { action in
                self.defaults.set(3, forKey: "birthMonth")
                self.present(alert3, animated: true, completion: nil)
            }))
            alert2.addAction(UIAlertAction(title: "April", style: .default, handler: { action in
                self.defaults.set(4, forKey: "birthMonth")
                self.present(alert3, animated: true, completion: nil)
            }))
            alert2.addAction(UIAlertAction(title: "May", style: .default, handler: { action in
                self.defaults.set(5, forKey: "birthMonth")
                self.present(alert3, animated: true, completion: nil)
            }))
            alert2.addAction(UIAlertAction(title: "June", style: .default, handler: { action in
                self.defaults.set(6, forKey: "birthMonth")
                self.present(alert3, animated: true, completion: nil)
            }))
            alert2.addAction(UIAlertAction(title: "July", style: .default, handler: { action in
                self.defaults.set(7, forKey: "birthMonth")
                self.present(alert3, animated: true, completion: nil)
            }))
            alert2.addAction(UIAlertAction(title: "August", style: .default, handler: { action in
                self.defaults.set(8, forKey: "birthMonth")
                self.present(alert3, animated: true, completion: nil)
            }))
            alert2.addAction(UIAlertAction(title: "September", style: .default, handler: { action in
                self.defaults.set(9, forKey: "birthMonth")
                self.present(alert3, animated: true, completion: nil)
            }))
            alert2.addAction(UIAlertAction(title: "October", style: .default, handler: { action in
                self.defaults.set(10, forKey: "birthMonth")
                self.present(alert3, animated: true, completion: nil)
            }))
            alert2.addAction(UIAlertAction(title: "November", style: .default, handler: { action in
                self.defaults.set(11, forKey: "birthMonth")
                self.present(alert3, animated: true, completion: nil)
            }))
            alert2.addAction(UIAlertAction(title: "December", style: .default, handler: { action in
                self.defaults.set(12, forKey: "birthMonth")
                self.present(alert3, animated: true, completion: nil)
            }))
            
            let alert = UIAlertController(title: "Welcome!", message: "Looks like you're new here! To get started, let's grab your baby's name!", preferredStyle: .alert)
            alert.addTextField { (textField) in
                textField.text = "Name"
            }
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
                let textField = alert?.textFields![0]
                self.defaults.set(textField?.text, forKey: "Name")
                self.babyName.text = textField?.text
                self.present(alert2, animated: true, completion: nil)
            }))
            
            
            
            
            self.present(alert, animated: true, completion: nil)
            //self.present(alert2, animated: true, completion: nil)
            //self.present(alert3, animated: true, completion: nil)
            
            
        }
    }
    
    
    
    
    


}

