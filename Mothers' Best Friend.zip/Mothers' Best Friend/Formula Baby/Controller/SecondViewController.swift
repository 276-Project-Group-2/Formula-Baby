//
//  SecondViewController.swift
//  Formula Baby
//
//  Created by Alec Grover on 2018-07-03.
//  Copyright © 2018 Team NASK. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
//    var qL = QuestionBank()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        let faqView = FAQView(frame: view.frame, items: qL.qArray)
//        view.addSubview(faqView)
//        faqView.viewBackgroundColor = UIColor(red: 0, green: 174, blue: 249, alpha: 1)
//        faqView.titleLabel.text = "Frequently Asked Questions"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

