//
//  StoreList.swift
//  Formula Baby
//
//  Created by User on 2018-07-03.
//  Copyright © 2018 Team NASK. All rights reserved.
//  
//  Master array of items in the market

import Foundation

class StoreList {
    var sArray = [FAQItem]()
    init() {
        sArray.append(FAQItem(question: "Diapers", answer: "Pampers Baby Dry:\n\nDisposable Diapers, 128-252 Count\n\n$37.28\n\nSize 1:\n https://amzn.to/2zbHsI4 \n\nSize 2:\nhttps://amzn.to/2u4EL5d \n\nSize 3:\nhttps://amzn.to/2NnJs2N \n\nSize 4:\nhttps://amzn.to/2MMZDpe \n\nSize 5:\nhttps://amzn.to/2lTEoXl \n\nSize 6:\nhttps://amzn.to/2lSgaNa \n\n\nHUGGIES Snug & Dry:\n\n128-252 Count\n\n$37.28-$39.99\n\nSize 1:\nhttps://amzn.to/2KrXJxA \n\nSize 2:\nhttps://amzn.to/2u74xpk \n\n Size 3:\nhttps://amzn.to/2MQzPbJ\n\nSize 4:\nhttps://amzn.to/2ISoCFs \n\nSize 5:\nhttps://amzn.to/2ISk3Ln \n\nSize 6:\nhttps://amzn.to/2zdtENa\n\n"))
        sArray.append(FAQItem(question: "Formula", answer: "Nature’s One\n\nToddler Formula, DHA & ARA, Dairy, Iron Fortified\n\n12.7 oz (360 g), 2 Count\n\n$62.18\n\nhttps://amzn.to/2IVnGjs\n\nBaby’s Only\n\nSoy Organic Toddler Formula, Iron Fortified, 12.7 oz (360 g), 3 Count\n\n$91.62\n\nhttps://amzn.to/2lQy1Eh"))
        sArray.append(FAQItem(question: "Baby Wipes", answer: "Pampers:\nSensitive\n\n 9X Refill Packs, 576 Count\n\n$21.99 CADhttps://amzn.to/2IQ9qbX\n\nSensitive UNSCENTED\n\n16X Refill Packs, 1024 Count\n\n$24.98 CAD\n\nhttps://amzn.to/2KJqEct\n\nComplete Clean UNSCENTED\n\n16X Refill, 1152 Count\n\n$24.98\n\nhttps://amzn.to/2NoRbhj\n\nHuggies:\n\nNatural Care\n\nFragrange-Free and Hypoallergenic\n\n3X Refill Packs, 168 Count\n\n$8.49\n\nhttps://amzn.to/2KNo2Oo \n\n1 Tub, 4X Refill Packs, 800 Count\n\n$23.99\n\nhttps://amzn.to/2tSV0CW \n\nRefill Kit, 1056 Count\n\n$24.98\n\nhttps://amzn.to/2lWdcHM"))
        sArray.append(FAQItem(question: "Baby Food", answer: "HEINZ:\n\nStrained Apple, Sweet Potato & Carrot Pouch\n\n6 Pack, 128 mL Each\n\n$6.84\n\nhttps://amzn.to/2KM3wuf \n\nPear, Raspberry, Yoghurt & Oatmeal Pouch\n\n6 Pack, 128 mL Each\n\n$6.84\n\nhttps://amzn.to/2MK328w \n\nEarth’s Best:\n\nCarrots – Stage 1\n\n12 Count\n\n$9.60\n\nhttps://amzn.to/2MLfEvR \n\nPears – Stage 1\n\n12 Count\n\n$8.88\n\nhttps://amzn.to/2u6hJuB \n\n Peaches/Apples Oatmeal – Stage 2\n\n12 Count\n\n$8.88\n\nhttps://amzn.to/2MMenot\n\nPears/Mangos – Stage 2\n\n12 Count\n\n$9.60\n\nhttps://amzn.to/2lVnCra\n\nBaby Gourmet:\n\nJuicy Pear Garden Greens\n\n12 Count\n\n$17.88\n\nhttps://amzn.to/2lUJLG2 \n\nApple Sweet Potato Berry Swirl\n\n12 Count\n\n$20.04\n\nhttps://amzn.to/2KIY2ne"))
        //sArray.append(FAQItem(question: "<#T##String#>", answer: "<#T##String#>"))
    }
}
