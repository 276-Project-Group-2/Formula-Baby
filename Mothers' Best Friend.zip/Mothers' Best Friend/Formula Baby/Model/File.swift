//
//  File.swift
//  Formula Baby
//
//  Created by User on 2018-08-01.
//  Copyright © 2018 Team NASK. All rights reserved.
//

import Foundation

class CanIBreastfeedIfBank {
    var qArray = [FAQItem] ()
    init () {
        qArray.append(FAQItem(question: "Is it okay to breastfeed my child if I smoke cigarettes, use street drugs, etc?", answer: "It is not recommended to do these things if you are breastfeeding, as harmful ingredients can pass through your breast milk and affect your toddler. However, it is still better to breastfeed than not because of how good it is for your baby.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf "))
        qArray.append(FAQItem(question: "Can I continue breastfeeding if I want my baby to learn to become independent?", answer: "Yes. It is shown by some studies that babies who are breastfed for longer than 12 months achieve independence at their own pace and become more secure than a baby weaned at a younger age.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "Can I breastfeed if I have to take prescribed medication?", answer: "It is safe to take most medications while breastfeeding, but not all medications can be taken. It is recommended to check with your doctor, and if there is a conflict, they may be able to prescribe something else.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf "))
        qArray.append(FAQItem(question: "Can I breastfeed if I get pregnant again?", answer: "Yes, you can breastfeed if you pregnant again. However, you need to be careful to ensure that you are getting enough nutrition for your unborn child, baby, and yourself. It is recommended to talk to your health-care provider about vitamin supplements to meet your need for extra vitamins. \n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
    }
}



class ChokingAndAllergiesBank {
    var qArray = [FAQItem] ()
    init () {
        qArray.append(FAQItem(question: "How can I prevent my baby from choking on solid food?", answer: "Children under the age of four do not have mouth muscles that are developed enough to control hard or slippery foods. To help prevent choking, you should not offer your child under the age of four foods that are easy to choke on. You should also stay with your child when they eat, and not allow them to eat while walking, in a stroller, or riding in a vehicle.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf "))
        qArray.append(FAQItem(question: "What are some foods that are easy to choke on?", answer: "Some foods that are very likely to cause choking are whole nuts, whole peanuts, whole grapes, popcorn, gum, cough drops, and hard candies.\n\nFor a full chart on reducing choking hazards, view page 70 of https://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf."))
        qArray.append(FAQItem(question: "What are signs that my baby has had an allergic reaction to a new food?", answer: "Signs include: Belly pain, coughing, diarrhea, fainting, hives or rash, nausea, vomiting, runny or stuffy nose, swelling of the face, legs, or arms, tightness in the throat, breathing troubles, and wheezing\n\nIt is recommended to call your baby’s doctor for advice if you notice hives, vomiting, or diarrhea\n\nIf your baby is having breathing troubles, wheezing, or swelling in the face, call 911 or your local emergency number as your baby may be having a life threatening allergic reaction.\n\nhttps://www.babycenter.com/0_introducing-solids_113.bc\nhttps://www.webmd.com/allergies/allergies-babies-toddlers#1"))
        qArray.append(FAQItem(question: "What are common food allergens?", answer: "Eggs, Milk, Mustard, Peanuts, Seafood, Sesame, Soy, tree nuts. Wheat\n\nhttps://www.beststart.org/resources/nutrition/pdf/BSRC_FeedingYourBaby_2015.pdf"))
    }
}

class EatingSkillsBank {
    var qArray = [FAQItem] ()
    init () {
        qArray.append(FAQItem(question: "What eating skills can I expect when my baby is 6-9 months old?", answer: "Typically, you can expect your baby to:\n-Pick up food with their fingers and put it in their mouth\n-Bite off food\n-Close lips around a cup if held by an adult\n-Chew food by moving it to the sides of their mouth or from front to back, munching up and down and/or grinding food with their jaws\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "What eating skills can I expect when my baby is 9-12 months old?", answer: "Typically, you can expect your baby to:\n-Chew up and down\n-Use thumb and fingers to pick up small pieces of food\n-Can hold cup in two hands\n-Twist and turn hand when using a spoon\n-Drop things from a high chair\n-Want to sit a the family table and feed themself\n-Can feed themself with fingers or spoons, but likely needs some help\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "What eating skills can I expect when my baby is 12-24 months old?", answer: "Typically, you can expect your baby to:\n-Feed themself with fingers or spoon, but is messy\n-Be inconsistent with the amount they eat\n-Take food in and out of mouth\n-Be easily distracted\n-Possibly throw food\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
    }
}

class FoodSafetyBank {
    var qArray = [FAQItem] ()
    init () {
        qArray.append(FAQItem(question: "How can I tell if meat is cooked enough for my baby to eat?", answer: "The following temperatures are the temperatures at which meats are well cooked:\n\nBeef: 63°C (145°F)\nGround Beef: 71°C (160°F)Poultry: 74°C (165°F)\n\nPork: 71°C (160°F)\n\nFor a safe, easy to remember temperature, cook all meats to 74°C (165°F)\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf "))
        qArray.append(FAQItem(question: "Can I feed my baby the food my family eats?", answer: "Yes, to make homemade baby food, you can mash the food your family eats. It is not necessary to puree your food for your baby to enjoy it, as they can eat well mashed foods even without teeth.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "How can I ensure my homemade baby food is safe?", answer: "Wash your counters and equipment with soap and water immediately after using, especially if raw meat is involved and discard cutting boards that are worn, as germs can hide in these\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf "))
        qArray.append(FAQItem(question: "How long can I store leftover baby food?", answer: "Leftovers in the refrigerator should be stored for no longer than two to three days. Frozen leftovers should be used within two months.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf "))
        qArray.append(FAQItem(question: "How do I keep my baby’s food safe?", answer: "If your baby is full and you are aving leftovers, throw out any food that has come in contact with its saliva.\nRefreezing thawed food is not recommended.\nChecking the best before date.\nMaking sure safety seals on store bought products are not broken.\nDefrost raw meat, fish and seafood in the fridge, microwave or in a sealed bag sumberged in cold water.\n-When using a microwave make sure you cook it right away after thawing\n\nhttps://www.beststart.org/resources/nutrition/pdf/BSRC_FeedingYourBaby_2015.pdf"))
    }
}

class HungerBank {
    var qArray = [FAQItem] ()
    init () {
        qArray.append(FAQItem(question: "How much food does my baby need?", answer: "As a parent or caregiver you control what you feed the baby\nThe baby decides if they are hungry and how much they will eat\n-Your baby is hungry when they open their mouth for food, or get upset if the food is taken away.\n-Your baby becomes excited when offered food, such as kicking their feet or waving their hands\n\nhttps://www.healthlinkbc.ca/healthlinkbc-files/babys-first-foods"))
        qArray.append(FAQItem(question: "What are some cues the my baby is hungry?", answer: "Your baby opens their mouth when offered food or becomes excited when offered food, such as kicking their feet or waving their hands\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf "))
        qArray.append(FAQItem(question: "How can I tell if my baby is full or not hungry?", answer: "If your baby is full they will close their mouth or turn their head away when offered food, or they will push food away.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "What should I do if my baby will not eat their food?", answer: "If your baby will not eat their food, it is likely that they are not hungry. You should not force your baby to eat if they are not hungry, instead you should allow them to leave the table and wait to feed them until the next regular meal or snack time.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "Is it okay to bribe my baby to finish their food?", answer: "You should avoid using things such as dessert or playtime to bribe your child to finish their food.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
    }
}

class OtherBank {
    var qArray = [FAQItem] ()
    init () {
        qArray.append(FAQItem(question: "What equipment is helpful for feeding solids to my baby?", answer: "Equipment that could be helpful includes:\n-A Highchair-Plastic Dishes (to reduce chance of breaking)-Plastic Spoons (to protect your babies gums)-Bibs-A Table-A mat to catch food\n\nhttps://www.babycenter.com/0_introducing-solids_113.bc"))
        qArray.append(FAQItem(question: "Is it normal for my baby to have constipation when solids are introduced?", answer: "It is not uncommon for babies to have constipation when solids are introduced, although it is usually temporary. It is recommended by some doctors to add fruits such as pears, prunes, peaches, or other high-fiber fruits to help his bowel movements return to normal.\n\nhttps://www.babycenter.com/0_introducing-solids_113.bc"))
        qArray.append(FAQItem(question: "Is it normal for my baby to gag when switching to solid foods?", answer: "Yes, gagging is a normal part of learning to eat. A baby’s gag reflex is sensitive, and gagging is a sign of learning to eat without choking. If your baby gags, stay calm and reassure them so they are not afraid to try new foods.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "Can my baby be a vegan?", answer: "If you want your baby to eat vegan, consult a registered dietitian to ensure that your baby is getting the nutrients they need.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "What are easy, nutritious snacks for on the go eating?", answer: "Some recommended snacks for on the go eating are: dry cereal, cheese and crackers, and cut-up fruits or vegetables.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
    }
}

class PickyEatingBank {
    var qArray = [FAQItem] ()
    init () {
        qArray.append(FAQItem(question: "How should I introduce a new solid food to my baby?", answer: "Solid foods should be introduced gradually, and should be introduced one at a time. A new food should be fed to your baby multiple times over a few days before a new food is tried, in order to tell if your baby has had an allergic reaction and also so they can get adjusted to the new taste and texture.\n\nhttps://www.babycenter.com/0_introducing-solids_113.bc"))
        qArray.append(FAQItem(question: "What if my baby refuses a new food?", answer: "If your baby does not accept food the first time, try another day, it may take 8-10 more tries for baby to accept\nMix feeding the baby the new food with breastmilk to make it more familiar\nTry to let baby feed itself with fingers or fists\nServe food at different temperatures\nOffer new food when you think your baby is most hungry and not tired"))
        qArray.append(FAQItem(question: "How can I prevent my baby from being a picky eater?", answer: "It is important to give your baby many opportunities to smell, touch, and taste new foods so they can accept them. Offering a new food along with a food your baby already likes is recommended. You should also provide foods with a variety of different textures, as this will allow your baby to more easily accept them.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))


    }
}

class WeaningBank {
    var qArray = [FAQItem] ()
    init () {
        qArray.append(FAQItem(question: "What age should I start introducing solids to my baby?", answer: "It is recommended by Canadian experts to start introducing solids to your baby at about the age of 6 months. However, some babies show signs of readiness as early as 4 months.\n\nhttps://www.healthlinkbc.ca/health-topics/te4473,\nhttps://www.babycenter.com/0_introducing-solids_113.bc"))
        qArray.append(FAQItem(question: "What are signs that my baby is ready to have solids introduced to their diet?", answer: "Some key signs that your baby is ready to have solids introduced to their diet are:\n-Your baby is able to sit upright when being supported\n-Your baby has good control over their head and neck\n-Your baby does not instinctively attempt to push objects placed in their mouth out using their tongue\n-Your baby displays curiosity about food\n-Your baby has undergone significant weight gain\n\nhttps://www.healthlinkbc.ca/health-topics/te4473, https://www.babycenter.com/0_introducing-solids_113.bc, https://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf "))
        qArray.append(FAQItem(question: "When should I stop breastfeeding my baby?", answer: "You should not have to wean your child, weaning will occur naturally. Your baby will stop breastfeeding at their own pace. However, you can wean your baby yourself starting at around 6 months.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "What are some benefits of allowing my child to wean naturally?", answer: "Allowing your child to wean naturally can help you and your baby have an easier adjustment to the end of the breastfeeding relationship. It also allows your body to naturally reduce the amount of milk produced, preventing your breasts from becoming overfull and uncomfortable.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "How can I make the weaning process more comfortable?", answer: "Tips to help make the process smoother for you and your baby are:\nPlan: Start the weaning process at a non-stressful time.\nStart slowly: For the first week, choose the feeding that provides the least comfort your your baby and replace it.\nContinue to skip: Continually replace the feeding that provides the least comfort for your baby every week with food and other fluids.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "Is it normal for my baby to need more attention during and after weaning?", answer: "You may find that your baby needs more attention during and after weaning, including more time spent holding, comforting, and settling your baby.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
    }
}

class WhatToFeedMyBabyBank {
    var qArray = [FAQItem] ()
    init () {
        qArray.append(FAQItem(question: "What are the best solid foods to start feeding my baby?", answer: "The best solid foods to start your baby on are iron-rich foods. These include, but are not limited to: Beef, pork, lamb, veal, iron-fortified infant cereals, chicken, turkey, fish, cooked tofu, egg yolks, beans, and other legumes.\n\nYour baby can eat many of the same healthy foods enjoyed by the rest of the family, offer foods that are made with little or no added sugar or salt.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf, https://www.healthlinkbc.ca/healthlinkbc-files/babys-first-foods "))
        qArray.append(FAQItem(question: "What do I feed my baby when it has no teeth?", answer: "Your baby can eat soft foods and finger foods before they have teeth\n\nFinger foods include: Small pieces of cooked vegetables and soft fruits without the skin, strips of toast or roti, cooked pasta, and ‘oat rings’ cereal\n\nSoft foods include: Minced, mashed, ground, lumpy, pureed, and tender-cooked foods\n\nhttps://www.healthlinkbc.ca/healthlinkbc-files/babys-first-foods"))
        qArray.append(FAQItem(question: "How often should iron-rich foods be fed to my baby?", answer: "In order to ensure that your baby is receiving enough iron, iron-rich foods should be fed at least twice a day.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "How often should I feed my baby solids?", answer: "The answer to this question depends on the age of your baby\n\nFrom the age of 6 months to 9 months, it is recommended to offer a variety of solid foods at two to three feedings per day, as well as two snacks per day.\n\nFrom the age of 9 months to 12 months, it is recommended to offer a variety of solid foods at three feedings per day, as well as one to two snacks per day.\n\nFrom the age of 12 months to 24 months, it is recommended to offer a variety of solid foods from each of the food groups three to four time per day, as well as one to two snacks per day.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "Are there any important supplements or specific vitamins I should be giving to my baby?", answer: "Health Canada recommends that all breastfed, healthy, full term babies get a daily liquid vitamin D supplement of 400 IU per day.\n\nIf your baby is only fed formula, then your baby does NOT need a vitamin D supplement. If your baby is fed breastmilk and formula, then your baby will also need a vitamin D supplement\n\nYou can find vitamin D supplements at local pharmacy or health food store. Supplementing should start right after birth\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/BabysBestChance-Sept2017.pdf"))
        qArray.append(FAQItem(question: "What is an IU?", answer: "An IU is an International Unit, 400 IU is 10 micrograms"))
    }
}
