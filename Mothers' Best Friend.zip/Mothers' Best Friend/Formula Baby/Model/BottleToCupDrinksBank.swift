//
//  BottleToCupDrinksBank.swift
//  Formula Baby
//
//  Created by User on 2018-08-01.
//  Copyright © 2018 Team NASK. All rights reserved.
//

import Foundation

class BottleToCupDrinksBank {
    var qArray = [FAQItem] ()
    init () {
        qArray.append(FAQItem(question: "How can I make the change from a bottle to a cup smooth?", answer: "In order to make this change go smoothly, you can use a cup with your baby’s meals and snacks. You can reduce the amount of milk given in a bottle for each feed, potentially preventing your baby from noticing the change much. You should stay with your baby when they drink from a cup to prevent choking and spills.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "Why is it necessary to switch from a bottle to a cup?", answer: "There is a potential that your baby may experience tooth decay if they around with a bottle during a day constantly sipping from it.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "Is a sip cup helpful for switching from a bottle?", answer: "Sip cups are not very helpful because they are more like bottles than cups. This is because of the valve that stop spills causing the baby to suck rather than sip.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "Can my baby have drinks with caffeine?", answer: "Caffeine can cause rapid heart rate and make your toddler excited or anxious, and as such, drinks with caffeine are not recommended to be offered to your baby.\n\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf"))
        qArray.append(FAQItem(question: "When can I give my baby cow milk?", answer: "You can start offering small amounts of pasteurized whole cow milk (3.25% milk fat) in an open cup when your baby is 9-12 months and eating a vierty of foods that are rich in iron. DO NOT feed your baby lower fat (2% or 1%) or skin milk before 2 years of age.\n\nhttps://www.healthlinkbc.ca/healthlinkbc-files/babys-first-foods "))
    }
}
