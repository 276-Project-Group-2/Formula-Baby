//
//  FAQ.swift
//  Formula Baby
//
//  Created by Alec Grover on 2018-07-03.
//  Copyright © 2018 Team NASK. All rights reserved.
//
//  Currently unused class for FAQ Items, replaced by open source FAQ system in FAQView.swift

import Foundation

class FAQ {
    var question : String
    var answer : String
    var open : Bool
    init( newQ : String, newA : String ) {
        question = newQ
        answer = newA
        open = false
    }
}
