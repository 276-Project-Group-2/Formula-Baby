//
//  StoreItem.swift
//  Formula Baby
//
//  Created by User on 2018-07-03.
//  Copyright © 2018 Team NASK. All rights reserved.
//
//  Currently unused class for items in the market tab, planned to be integrated at a later date

import Foundation

class StoreItem {
    var question : String
    var answer : String
    var link : String
    var image : String
    init( item : String, details : String, newLink : String ) {
        question = item
        answer = details
        image = "placeholder"
        link = newLink
    }
}
