//
//  FifthViewController.swift
//  Formula Baby
//
//  Created by Prashant Bhatnagar on 15/07/18.
//  Copyright © 2018 Team NASK. All rights reserved.
//

//import Foundation
import UIKit
import Charts

class FifthViewController: UIViewController {

    @IBOutlet weak var txtTextBox: UITextField!
    @IBOutlet weak var chtChart: LineChartView!
    
    var numbers : [Double] = []
    let defaults = UserDefaults.standard
   
   // let numbers = defaults.object(forKey: "Numbers1") as? [Double] ?? [Double]()
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        var date = DateComponents()
        date.hour = 15
        date.minute = 49
        
        numbers = defaults.object(forKey: "Numbers1") as? [Double] ?? [Double]()
        
        if(numbers.count > 6)
        {
            numbers.removeAll()
        }
        
        let date2 = DateComponents()
        if(date==date2)
        {
            numbers.removeAll()

        }
       
        
        updateGraph()
       
    }

override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
}
    
    
    @IBAction func btnbutton(_ sender: Any) {
        
        let input = Double(txtTextBox.text!)
        numbers.append(input!)
        
        if(numbers.count > 6)
        {
            numbers.removeAll()
        }

        defaults.set(numbers,forKey: "Numbers1")

        updateGraph()
        
    }
    
    func updateGraph()
    {
        var LineChartEntry = [ChartDataEntry]()

        var numbers = defaults.object(forKey: "Numbers1") as? [Double] ?? [Double]()
        
 
        for i in 0..<numbers.count
        {
            let value = ChartDataEntry(x: Double(i) , y:numbers[i])
            LineChartEntry.append(value)
        }
        
        let line1 = LineChartDataSet(values: LineChartEntry , label: "Number")
        line1.colors = [NSUIColor.blue]
        
        let data = LineChartData()
        data.addDataSet(line1)
        chtChart.data = data
        chtChart.chartDescription?.text = "Food Portion Chart"
     

        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
    }
    
    
}
