//
//  ResourceList.swift
//  Formula Baby
//
//  Created by User on 2018-07-03.
//  Copyright © 2018 Team NASK. All rights reserved.
//
//  Master array of resources in the Library

import Foundation

class ResourceList {
    var rArray = [FAQItem]()
    init() {
        rArray.append(FAQItem(question: "Diaper Size Chart", answer: "http://diaper-sizes.org"))
        rArray.append(FAQItem(question: "Preparing Meat for Your Baby", answer: "http://wholesomebabyfood.momtastic.com/meats.htm"))
        rArray.append(FAQItem(question: "More on Introducing Solid Foods", answer: "Health Link BC:\nhttps://www.healthlinkbc.ca/health-topics/te4473\n\nBaby Center:\nhttps://www.babycenter.com/0_introducing-solids_113.bc\nhttps://www.healthlinkbc.ca/healthlinkbc-files/babys-first-foods \n\nBC Health:\nhttps://www.health.gov.bc.ca/library/publications/year/2017/ToddlersFirstSteps-Sept2017.pdf \n\nBest Start:\nhttps://www.beststart.org/resources/nutrition/pdf/BSRC_FeedingYourBaby_2015.pdf"))
        rArray.append(FAQItem(question: "About Baby Allergies", answer: "Web MD:\nhttps://www.webmd.com/allergies/allergies-babies-toddlers#1\n\nBest Start:\nhttps://www.beststart.org/resources/nutrition/pdf/BSRC_FeedingYourBaby_2015.pdf"))
    }
}
