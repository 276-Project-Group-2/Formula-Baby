//
//  ThirdViewController.swift
//  Formula Baby
//
//  Created by Alec Grover on 2018-07-03.
//  Copyright © 2018 Team NASK. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    var storeList = StoreList()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let faqView = FAQView(frame: view.frame, items: storeList.sArray)
        view.addSubview(faqView)
        faqView.viewBackgroundColor = UIColor(red: 0, green: 174, blue: 249, alpha: 1)
        faqView.dataDetectorTypes = [.link]
        faqView.titleLabel.text = "Market"
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
