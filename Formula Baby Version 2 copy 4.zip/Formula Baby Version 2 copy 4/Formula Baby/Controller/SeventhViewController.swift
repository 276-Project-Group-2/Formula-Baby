//
//  SeventhViewController.swift
//  Formula Baby
//
//  Created by Prashant Bhatnagar on 30/07/18.
//  Copyright © 2018 Team NASK. All rights reserved.
//

import UIKit
import Foundation

var sleepTime: [Double] = []
var cur2 = 0.0
var flag2 = false
var avgSleepTime: [Double] = []
var avgSleepTotal: [Double] = []
var AVG = 0.0
var AVG2 = 0.0
var AVG3 = 0.0
var NUM = 0
var NUM2 = avgSleepTime.count
var NUM3 = avgSleepTotal.count
class SeventhViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        sleepTime = defaults.object(forKey: "sleep1") as? [Double] ?? [Double]()
        avgSleepTime = defaults.object(forKey: "sleep2") as? [Double] ?? [Double]()
        avgSleepTotal = defaults.object(forKey: "sleep3") as? [Double] ?? [Double]()
        if(NUM2 > 0)
        {
            AvgNapTime.text = String(round(AvgHoursSlept()))
            AvgTotal.text = String(round(AvgTotalSleeptime()))
        }
        
//
//        sleepTime.removeAll()
//                avgSleepTime.removeAll()
//                avgSleepTotal.removeAll()
//                defaults.set(sleepTime,forKey: "sleep1")
//                defaults.set(avgSleepTime,forKey: "sleep2")
//                defaults.set(avgSleepTotal,forKey: "sleep3")
//
//
        

        // Do any additional setup after loading the view.
    }

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var label1: UILabel!
    @IBAction func Stepper2(_ sender: UIStepper) {
        
        if(flag == true)
        {
            sender.value = 0.00
            flag = false
        }
        label1.text = String(sender.value)
        cur2 = sender.value
    }
    
    @IBAction func addNap(_ sender: Any) {
        
        print(cur2)
        sleepTime.append(cur2)
        defaults.set(sleepTime,forKey: "sleep1")
        print(sleepTime)
        
        label1.text = "0.0"
        if( flag == false)
        {
            flag = true
        }
        
    }
    
    @IBOutlet weak var AvgNapTime: UILabel!
    @IBOutlet weak var AvgTotal: UILabel!
    
    
    @IBAction func AverageSleep(_ sender: Any) {
        
        AVG = avgNapTime()
        print(AVG)
        //  Avg()
        avgSleepTime.append(AVG)
        NUM = avgSleepTime.count
        defaults.set(sleepTime,forKey: "sleep1")
        defaults.set(avgSleepTime,forKey: "sleep2")
        defaults.set(avgSleepTotal,forKey: "sleep3")

        sleepTime.removeAll()
        print(sleepTime)
        
        print(avgSleepTime)

        
        if(NUM > 0)
        {
            AvgNapTime.text = String(round(AvgHoursSlept()))
            AvgTotal.text = String(round(AvgTotalSleeptime()))
            
            
            
        }


        
        
        
        
        
    }
    
    
    func avgNapTime() -> Double
    {
        let size = sleepTime.count
        var value = 0.00
        for n in 0...size-1
        {
            value = value + sleepTime[n]
        }
        avgSleepTotal.append(value)
        defaults.set(avgSleepTotal,forKey: "sleep3")
        
        AVG = value/Double(size)
        print(avgSleepTotal)
        
        return AVG
        
    }
    func AvgHoursSlept() -> Double
    {
        let size = avgSleepTime.count
        var value = 0.00
        for n in 0...size-1
        {
            value = value + avgSleepTime[n]
        }
        AVG2 = value/Double(size)
        return AVG2
        
    }
    func AvgTotalSleeptime() -> Double
    {
        let size = avgSleepTotal.count
        var value = 0.00
        for n in 0...size-1
        {
            value = value + avgSleepTotal[n]
        }
        AVG3 = value/Double(size)
        return AVG3
        
    }
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
