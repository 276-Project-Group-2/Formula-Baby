//
//  SixthViewController.swift
//  Formula Baby
//
//  Created by Prashant Bhatnagar on 26/07/18.
//  Copyright © 2018 Team NASK. All rights reserved.
//

import UIKit
import Foundation

var numbers: [Double] = []
var RunningAvg: [Double] = []
var TotalPortion: [Double] = []
var cur = 0.00
var count = 0
var date = DateComponents()
var avg = 0.00
var avg2 = 0.00
var avg3 = 0.00


var flag = false
let defaults = UserDefaults.standard
var num = RunningAvg.count
var num2 = TotalPortion.count


var CheckDate = Date()
var calendar = Calendar.current



class SixthViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        numbers = defaults.object(forKey: "Numbers1") as? [Double] ?? [Double]()
        RunningAvg = defaults.object(forKey: "Numbers2") as? [Double] ?? [Double]()
        TotalPortion = defaults.object(forKey: "Numbers3") as? [Double] ?? [Double]()

//        if(num > 0)
//        {
//        Check.text = String(round(Avg2()))
//        }
//        if(num2 > 0)
//        {
//            Check2.text = String(round(Avg3()))
//        }
        
        if(num2 > 0)
        {
            Check.text = String(round(Avg2()))
            Check2.text = String(round(Avg3()))
            
        }

//        //
//        numbers.removeAll()
//        RunningAvg.removeAll()
//        TotalPortion.removeAll()
//        defaults.set(numbers,forKey: "Numbers1")
//        defaults.set(RunningAvg,forKey: "Numbers2")
//        defaults.set(TotalPortion,forKey: "Numbers3")
//
//        if(num > 0)
//        {
//            Check.text = String(Avg2())
//        }
//        print(numbers)
//        print(RunningAvg)


        

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        var MainDate = defaults.object(forKey: "MainDate") as? Int
                let CompareDate = calendar.component(.day, from: CheckDate)
        
                if(MainDate != CompareDate)
                {
                    MainDate = CompareDate
                    defaults.set(MainDate,forKey: "MainDate")
                    calculateAverage()
                }
        
//                if(num > 0)
//                {
//                    Check.text = String(round(Avg2()))
//                }
//                if(num2 > 0)
//                {
//                    Check2.text = String(round(Avg3()))
//                }
        if(num2 > 0)
        {
            Check.text = String(round(Avg2()))
            Check2.text = String(round(Avg3()))
            
        }
        
        
        
        
        
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var lbl2: UILabel!
    
    @IBAction func Value(_ sender: UIStepper) {
        if(flag == true)
        {
            sender.value = 0.00
            flag = false
        }
        lbl.text = String(sender.value)
        cur = sender.value
        //sender.value = 0.00
    }
    
    @IBAction func AddFood(_ sender: Any) {
        
        var MainDate = calendar.component(.day, from: CheckDate)
        defaults.set(MainDate,forKey: "MainDate")
        
        
        print(cur)
        numbers.append(cur)
        defaults.set(numbers,forKey: "Numbers1")
        defaults.set(RunningAvg,forKey: "Numbers2")


        print("printint numbers---")
        print(numbers)
        lbl.text = "0"
        
        
        if( flag == false)
        {
            flag = true
        }
        
       count = count + 1
        
        
//        if(count > 6)
//        {
//            avg = Avg()
//            lbl2.text = String(avg)
//
//        }

        
    }
    
    func Avg() -> Double
    {
        let size = numbers.count
        var value = 0.00
        if(size > 0)
        {
        for n in 0...size-1
        {
            value = value + numbers[n]
        }
        TotalPortion.append(value)
        defaults.set(TotalPortion,forKey: "Numbers3")

        avg = value/Double(size)
        print(TotalPortion)
        }

        return avg
    
    }
    func Avg2() -> Double
    {
        let size = RunningAvg.count
        if(size > 0)
        {
        var value = 0.00
        for n in 0...size-1
        {
            value = value + RunningAvg[n]
        }
        avg2 = value/Double(size)
        }
        return avg2
        
    }
    func Avg3() -> Double
    {
        let size = TotalPortion.count
        var value = 0.00
        if(size > 0)
        {
        for n in 0...size-1
        {
            value = value + TotalPortion[n]
        }
        avg3 = value/Double(size)
        }
        return avg3
        
    }
    
    @IBOutlet weak var Check2: UILabel!
    @IBOutlet weak var Check: UILabel!
   // @IBAction func calculateAverage(_ sender: Any) {
    func calculateAverage() {
    
    
//        let size = numbers.count
//        var value = 0.00
//        for n in 0...size-1
//        {
//            value = value + numbers[n]
//        }
        //avg = value/Double(size)
        avg = Avg()
        print(avg)
      //  Avg()
        RunningAvg.append(avg)
        
         num = RunningAvg.count
        numbers.removeAll()
        print(numbers)
        defaults.set(numbers,forKey: "Numbers1")
        defaults.set(RunningAvg,forKey: "Numbers2")
        defaults.set(TotalPortion,forKey: "Numbers3")

        
        print(RunningAvg)
        //Check.text = String(RunningAvg[num-1])
        if(num > 0)
        {
            Check.text = String(round(Avg2()))
            Check2.text = String(round(Avg3()))

        }
        
//       if(num2 > 0)
//        {
//            Check2.text = String(Avg3())
//        }
// 
 
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
